import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare function debugLambdaModules(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
