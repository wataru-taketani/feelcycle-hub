export interface ProgramData {
    programCode: string;
    programName: string;
    genre: string;
    backgroundColor: string;
    textColor: string;
}
