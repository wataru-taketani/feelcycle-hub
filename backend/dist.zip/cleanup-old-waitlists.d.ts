declare function cleanupOldWaitlists(): Promise<void>;
export { cleanupOldWaitlists };
