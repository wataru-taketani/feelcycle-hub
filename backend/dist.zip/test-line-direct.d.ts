declare function testLineDirect(): Promise<void>;
export { testLineDirect };
