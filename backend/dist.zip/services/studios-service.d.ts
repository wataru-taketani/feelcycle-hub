import { StudioData, StudioCreateRequest } from '../types';
export declare class StudiosService {
    /**
     * Store studio data in DynamoDB
     */
    storeStudioData(studioData: StudioData): Promise<void>;
    /**
     * Store multiple studios in batch
     */
    storeStudiosData(studios: StudioData[]): Promise<void>;
    /**
     * Get studio by code
     */
    getStudioByCode(studioCode: string): Promise<StudioData | null>;
    /**
     * Get all studios
     */
    getAllStudios(): Promise<StudioData[]>;
    /**
     * Get next unprocessed studio for batch processing (with retry support)
     */
    getNextUnprocessedStudio(): Promise<StudioData | null>;
    /**
     * Mark studio as processed (with retry count management)
     */
    markStudioAsProcessed(studioCode: string, status: 'processing' | 'completed' | 'failed', errorMessage?: string): Promise<void>;
    /**
     * Reset all studio batch statuses for new daily run
     */
    resetAllBatchStatuses(): Promise<void>;
    /**
     * Get batch processing progress
     */
    getBatchProgress(): Promise<{
        total: number;
        completed: number;
        processing: number;
        failed: number;
        remaining: number;
    }>;
    /**
     * Get studios by region
     */
    getStudiosByRegion(region: string): Promise<StudioData[]>;
    /**
     * Create studio from request
     */
    createStudioData(request: StudioCreateRequest): StudioData;
    /**
     * Update existing studio data
     */
    updateStudioData(studioCode: string, updates: Partial<StudioCreateRequest>): Promise<void>;
    /**
     * Delete studio
     */
    deleteStudio(studioCode: string): Promise<void>;
    /**
     * Refresh all studios from scraping data (DEPRECATED - use safeRefreshStudiosFromScraping)
     */
    refreshStudiosFromScraping(scrapedStudios: Array<{
        code: string;
        name: string;
        region: string;
    }>): Promise<{
        created: number;
        updated: number;
        total: number;
    }>;
    /**
     * Safe refresh of studios with mark-and-sweep cleanup
     * Production-ready method with error handling and backup
     */
    safeRefreshStudiosFromScraping(scrapedStudios: Array<{
        code: string;
        name: string;
        region: string;
    }>): Promise<{
        created: number;
        updated: number;
        removed: number;
        total: number;
        backupCreated: boolean;
        errors: string[];
    }>;
    /**
     * Update studio data with scrape timestamp mark
     */
    private updateStudioWithScrapeMark;
}
export declare const studiosService: StudiosService;
