"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstructorScraper = void 0;
const puppeteer_core_1 = __importDefault(require("puppeteer-core"));
const chromium = require('@sparticuz/chromium').default;
const dateUtils_1 = require("../utils/dateUtils");
class InstructorScraper {
    static browser = null;
    /**
     * Initialize browser instance
     */
    static async initBrowser() {
        if (!this.browser) {
            const isLambda = process.env.AWS_LAMBDA_FUNCTION_NAME !== undefined;
            if (isLambda) {
                console.log('🌐 Initializing browser for Lambda environment...');
                try {
                    const executablePath = await chromium.executablePath();
                    console.log('📍 Chromium executable path:', executablePath);
                    this.browser = await puppeteer_core_1.default.launch({
                        args: [
                            ...chromium.args,
                            '--no-sandbox',
                            '--disable-setuid-sandbox',
                            '--disable-dev-shm-usage',
                            '--disable-accelerated-2d-canvas',
                            '--no-first-run',
                            '--no-zygote',
                            '--single-process',
                            '--disable-gpu',
                            '--disable-extensions',
                            '--disable-background-timer-throttling',
                            '--disable-backgrounding-occluded-windows',
                            '--disable-renderer-backgrounding',
                            '--disable-features=VizDisplayCompositor',
                            '--disable-ipc-flooding-protection',
                            '--disable-dev-tools',
                            '--disable-default-apps',
                            '--disable-hang-monitor',
                            '--disable-popup-blocking',
                            '--disable-prompt-on-repost',
                            '--disable-sync',
                            '--disable-web-security',
                            '--enable-automation',
                            '--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
                        ],
                        defaultViewport: chromium.defaultViewport,
                        executablePath,
                        headless: chromium.headless,
                    });
                }
                catch (error) {
                    console.error('❌ Failed to initialize browser:', error);
                    throw error;
                }
            }
            else {
                console.log('🖥️ Initializing browser for local development...');
                this.browser = await puppeteer_core_1.default.launch({
                    headless: true,
                    args: ['--no-sandbox', '--disable-setuid-sandbox'],
                });
            }
        }
        return this.browser;
    }
    /**
     * Close browser instance
     */
    static async closeBrowser() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
    }
    /**
     * Scrape all instructors from FEELCYCLE instructor index page
     */
    static async scrapeAllInstructors() {
        console.log('🎯 Starting instructor scraping...');
        const browser = await this.initBrowser();
        const page = await browser.newPage();
        try {
            // Navigate to instructor index page
            const url = 'https://m.feelcycle.com/menu/instructor/index';
            console.log(`📄 Navigating to: ${url}`);
            await page.goto(url, {
                waitUntil: 'networkidle2',
                timeout: 30000
            });
            // Wait for the page to load and instructor data to be rendered
            await page.waitForSelector('.instructor_lists', { timeout: 15000 });
            // Select "名前（ABC）順" option if not already selected
            try {
                const selectElement = await page.$('.v-select');
                if (selectElement) {
                    await selectElement.click();
                    await page.waitForTimeout(1000);
                    // Look for the ABC option and click it
                    const abcOption = await page.$('div:contains("名前（ABC）順")');
                    if (abcOption) {
                        await abcOption.click();
                        await page.waitForTimeout(2000);
                    }
                }
            }
            catch (error) {
                console.log('⚠️ Could not change sorting order, proceeding with current order');
            }
            // Scrape instructor data
            const instructorData = await page.evaluate(() => {
                const instructors = [];
                // Find all area sections
                const areaElements = document.querySelectorAll('.area');
                areaElements.forEach(areaElement => {
                    const category = areaElement.textContent?.trim() || '';
                    // Find the next instructor list after this area
                    let nextElement = areaElement.nextElementSibling;
                    while (nextElement && !nextElement.classList.contains('instructor_lists')) {
                        nextElement = nextElement.nextElementSibling;
                    }
                    if (nextElement && nextElement.classList.contains('instructor_lists')) {
                        const instructorItems = nextElement.querySelectorAll('li[data-insref]');
                        instructorItems.forEach(item => {
                            const linkElement = item.querySelector('a');
                            const nameElement = item.querySelector('.name');
                            const imageElement = item.querySelector('img');
                            if (linkElement && nameElement) {
                                const href = linkElement.getAttribute('href') || '';
                                const name = nameElement.textContent?.trim() || '';
                                // Extract instructor ID from URL
                                const uidMatch = href.match(/uid=(\d+)/);
                                const instructorId = uidMatch ? uidMatch[1] : '';
                                // Get image URL
                                let imageUrl = '';
                                if (imageElement) {
                                    const src = imageElement.getAttribute('src');
                                    const dataSrc = imageElement.getAttribute('data-src');
                                    imageUrl = dataSrc || src || '';
                                }
                                if (instructorId && name && category) {
                                    instructors.push({
                                        instructorId,
                                        name,
                                        imageUrl: imageUrl || undefined,
                                        category,
                                        detailUrl: href ? `https://m.feelcycle.com${href}` : undefined,
                                    });
                                }
                            }
                        });
                    }
                });
                return instructors;
            });
            console.log(`✅ Scraped ${instructorData.length} instructors`);
            // Convert to InstructorData format
            const currentTime = (0, dateUtils_1.getJSTISOString)();
            const ttl = (0, dateUtils_1.getTTLFromJST)(90); // 90 days TTL
            const processedInstructors = instructorData.map((instructor) => ({
                ...instructor,
                createdAt: currentTime,
                updatedAt: currentTime,
                ttl,
            }));
            return processedInstructors;
        }
        catch (error) {
            console.error('❌ Error scraping instructors:', error);
            throw error;
        }
        finally {
            await page.close();
        }
    }
    /**
     * Clean up resources
     */
    static async cleanup() {
        await this.closeBrowser();
    }
}
exports.InstructorScraper = InstructorScraper;
