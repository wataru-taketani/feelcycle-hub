import { LessonData } from '../types';
/**
 * Enhanced FEELCYCLE Scraper
 * JavaScript SPA読み込み待機とフォールバック機能強化
 */
export declare class EnhancedRealFeelcycleScraper {
    private static browser;
    /**
     * Initialize browser with enhanced configuration
     */
    static initBrowser(): Promise<any>;
    /**
     * Enhanced wait for Vue.js SPA content loading
     */
    static waitForSPAContent(page: any, timeout?: number): Promise<void>;
    /**
     * Enhanced multi-pattern selector with fallback
     */
    static findElementsWithFallback(page: any, selectorPatterns: string[], description: string): Promise<any[]>;
    /**
     * Enhanced studio selection with multiple patterns
     */
    static selectStudioEnhanced(page: any, studioCode: string): Promise<boolean>;
    /**
     * Enhanced lesson extraction with multiple selector patterns
     */
    static extractLessonsEnhanced(page: any, studioCode: string): Promise<{
        dateMapping: any[];
        allLessons: any[];
        error?: string;
        patterns?: any;
    }>;
    /**
     * Enhanced main scraping method with comprehensive fallbacks
     */
    static searchAllLessonsEnhanced(studioCode: string): Promise<LessonData[]>;
    /**
     * Extract available slots from status text
     */
    private static extractAvailableSlots;
    /**
     * Enhanced cleanup with comprehensive resource management
     */
    static cleanup(): Promise<void>;
}
