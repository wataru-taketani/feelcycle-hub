"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RealFeelcycleScraper = void 0;
const puppeteer_core_1 = __importDefault(require("puppeteer-core"));
const chromium = require('@sparticuz/chromium').default;
const dateUtils_1 = require("../utils/dateUtils");
class RealFeelcycleScraper {
    static browser = null;
    /**
     * Initialize browser instance
     */
    static async initBrowser() {
        if (!this.browser) {
            // Detect environment: Lambda vs Local development
            const isLambda = process.env.AWS_LAMBDA_FUNCTION_NAME !== undefined;
            if (isLambda) {
                console.log('🌐 Initializing browser for Lambda environment...');
                try {
                    // Get the Chromium executable path
                    const executablePath = await chromium.executablePath();
                    console.log('📍 Chromium executable path:', executablePath);
                    // Lambda-optimized browser configuration  
                    this.browser = await puppeteer_core_1.default.launch({
                        args: [
                            ...chromium.args,
                            '--no-sandbox',
                            '--disable-setuid-sandbox',
                            '--disable-dev-shm-usage',
                            '--disable-accelerated-2d-canvas',
                            '--no-first-run',
                            '--no-zygote',
                            '--single-process',
                            '--disable-gpu',
                            '--disable-extensions',
                            '--disable-background-timer-throttling',
                            '--disable-backgrounding-occluded-windows',
                            '--disable-renderer-backgrounding',
                            '--disable-features=VizDisplayCompositor',
                            '--disable-ipc-flooding-protection',
                            '--disable-dev-tools',
                            '--disable-default-apps',
                            '--disable-hang-monitor',
                            '--disable-popup-blocking',
                            '--disable-prompt-on-repost',
                            '--disable-sync',
                            '--disable-web-security',
                            '--enable-automation',
                            '--password-store=basic',
                            '--use-mock-keychain',
                            '--hide-crash-restore-bubble'
                        ],
                        defaultViewport: { width: 1280, height: 720 },
                        executablePath,
                        headless: true,
                        timeout: 60000,
                        protocolTimeout: 60000,
                        pipe: false
                    });
                    console.log('✅ Browser initialized successfully for Lambda');
                }
                catch (error) {
                    console.error('❌ Lambda browser initialization failed:', error);
                    throw new Error(`Lambda browser initialization failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
                }
            }
            else {
                console.log('🖥️  Initializing browser for local development...');
                try {
                    // Import regular puppeteer for local development
                    const puppeteerLocal = await Promise.resolve().then(() => __importStar(require('puppeteer')));
                    // Local development browser configuration
                    this.browser = await puppeteerLocal.default.launch({
                        args: [
                            '--no-sandbox',
                            '--disable-setuid-sandbox',
                            '--disable-dev-shm-usage',
                            '--disable-web-security',
                            '--disable-features=VizDisplayCompositor'
                        ],
                        defaultViewport: { width: 1280, height: 720 },
                        headless: true,
                        timeout: 30000
                    });
                    console.log('✅ Browser initialized successfully for local development');
                }
                catch (error) {
                    console.error('❌ Local browser initialization failed:', error);
                    throw new Error(`Local browser initialization failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
                }
            }
        }
        return this.browser;
    }
    /**
     * Get all available studios from FEELCYCLE reservation website
     */
    static async getRealStudios() {
        const browser = await this.initBrowser();
        const page = await browser.newPage();
        try {
            console.log('Fetching real studio data from FEELCYCLE reservation site...');
            await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
            await page.goto('https://m.feelcycle.com/reserve', {
                waitUntil: 'domcontentloaded',
                timeout: 60000
            });
            // Wait for the studio list to load
            await page.waitForSelector('li.address_item.handle', { timeout: 30000 });
            await new Promise(resolve => setTimeout(resolve, 2000));
            // Extract studio information from the reservation site
            const studios = await page.evaluate(() => {
                const studioElements = document.querySelectorAll('li.address_item.handle');
                const studios = [];
                studioElements.forEach(element => {
                    const nameElement = element.querySelector('.main');
                    const codeElement = element.querySelector('.sub');
                    if (nameElement && codeElement) {
                        const name = nameElement.textContent?.trim();
                        const codeText = codeElement.textContent?.trim();
                        if (name && codeText) {
                            // Extract code from (CODE) format
                            const codeMatch = codeText.match(/\(([^)]+)\)/);
                            if (codeMatch) {
                                const code = codeMatch[1].toLowerCase();
                                studios.push({
                                    code,
                                    name,
                                    region: 'unknown' // Will be determined by location
                                });
                            }
                        }
                    }
                });
                return studios;
            });
            console.log(`Found ${studios.length} studios from reservation site`);
            return studios;
        }
        catch (error) {
            console.error('Error fetching studios from reservation site:', error);
            throw error;
        }
        finally {
            await page.close();
        }
    }
    /**
     * Get all lessons for a specific studio (all dates at once)
     */
    static async searchAllLessons(studioCode) {
        let retryCount = 0;
        const maxRetries = 2;
        while (retryCount <= maxRetries) {
            let browser = null;
            let page = null;
            try {
                console.log(`🔄 Attempt ${retryCount + 1}/${maxRetries + 1}: Fetching all lesson data for ${studioCode} (all dates at once)...`);
                // Initialize fresh browser instance for each retry
                if (retryCount > 0) {
                    console.log('🔄 Retry detected, reinitializing browser...');
                    await this.cleanup();
                }
                browser = await this.initBrowser();
                page = await browser.newPage();
                // Set page configuration with reduced timeouts for Lambda
                await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
                await page.setDefaultTimeout(15000); // 30s -> 15s
                await page.setDefaultNavigationTimeout(15000); // 30s -> 15s
                // Step 1: Go to reservation site with optimized settings
                await page.goto('https://m.feelcycle.com/reserve', {
                    waitUntil: 'domcontentloaded', // Changed from networkidle2
                    timeout: 20000 // Reduced from 60s to 20s
                });
                // Wait for studio list to load with reduced timeout
                await page.waitForSelector('li.address_item.handle', { timeout: 10000 }); // 30s -> 10s
                await new Promise(resolve => setTimeout(resolve, 1000)); // 2s -> 1s
                // Step 2: Select studio (click on the matching studio)
                console.log(`Selecting studio ${studioCode}...`);
                const studioSelected = await page.evaluate((targetCode) => {
                    const studioElements = document.querySelectorAll('li.address_item.handle');
                    for (const element of Array.from(studioElements)) {
                        const codeElement = element.querySelector('.sub');
                        if (codeElement) {
                            const codeText = codeElement.textContent?.trim();
                            if (codeText) {
                                const codeMatch = codeText.match(/\(([^)]+)\)/);
                                if (codeMatch && codeMatch[1].toLowerCase() === targetCode) {
                                    element.click();
                                    return true;
                                }
                            }
                        }
                    }
                    return false;
                }, studioCode);
                if (!studioSelected) {
                    throw new Error(`Studio ${studioCode} not found`);
                }
                // Wait for schedule to load
                await new Promise(resolve => setTimeout(resolve, 6000));
                await page.waitForSelector('.header-sc-list .content .days', { timeout: 30000 });
                // Step 3: Get all lessons for all dates at once
                console.log(`Extracting all lessons for all dates...`);
                const allLessonsData = await page.evaluate(() => {
                    // 1. Get date mapping for all available dates
                    const dateElements = document.querySelectorAll('.header-sc-list .content .days');
                    const dateMapping = Array.from(dateElements).map((el, index) => ({
                        index,
                        text: el.textContent?.trim() || ''
                    }));
                    // 2. Get the main lesson container
                    const scList = document.querySelector('.sc_list.active');
                    if (!scList) {
                        return { dateMapping, allLessons: [] };
                    }
                    const contentElements = scList.querySelectorAll(':scope > .content');
                    const allLessons = [];
                    // 3. Extract lessons from each date column
                    contentElements.forEach((column, columnIndex) => {
                        const dateInfo = dateMapping[columnIndex];
                        if (!dateInfo)
                            return;
                        // Parse date text to get actual date
                        const dateText = dateInfo.text;
                        let actualDate = '';
                        // Parse different date formats like "7/18(金)", "7/19(土)" etc.
                        const dateMatch = dateText.match(/(\d{1,2})\/(\d{1,2})/);
                        if (dateMatch) {
                            const month = parseInt(dateMatch[1]);
                            const day = parseInt(dateMatch[2]);
                            // Get current year - assume same year
                            const currentYear = new Date().getFullYear();
                            actualDate = `${currentYear}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                        }
                        const lessonElements = column.querySelectorAll('.lesson.overflow_hidden');
                        lessonElements.forEach((element) => {
                            const timeElement = element.querySelector('.time');
                            const nameElement = element.querySelector('.lesson_name');
                            const instructorElement = element.querySelector('.instructor');
                            const statusElement = element.querySelector('.status');
                            if (timeElement && nameElement && instructorElement) {
                                const timeText = timeElement.textContent?.trim();
                                const nameText = nameElement.textContent?.trim();
                                const instructorText = instructorElement.textContent?.trim();
                                const statusText = statusElement?.textContent?.trim();
                                // Extract color information from lesson_name style attribute
                                const nameStyle = nameElement.style;
                                const backgroundColor = nameStyle.backgroundColor || '';
                                const textColor = nameStyle.color || '';
                                // Extract start and end time
                                const timeMatch = timeText?.match(/(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})/);
                                if (timeMatch && nameText && instructorText && actualDate) {
                                    const startTime = timeMatch[1];
                                    const endTime = timeMatch[2];
                                    // Check availability
                                    const isAvailable = !element.classList.contains('seat-disabled');
                                    // Extract program type from lesson name
                                    const programMatch = nameText.match(/^(BSL|BB1|BB2|BB3|BSB|BSW|BSWi)/);
                                    const program = programMatch ? programMatch[1] : 'OTHER';
                                    allLessons.push({
                                        date: actualDate,
                                        startTime,
                                        endTime,
                                        lessonName: nameText,
                                        instructor: instructorText,
                                        isAvailable,
                                        program,
                                        backgroundColor: backgroundColor || null,
                                        textColor: textColor || null,
                                        statusText: statusText || null,
                                        dateText: dateText,
                                        columnIndex
                                    });
                                }
                            }
                        });
                    });
                    return { dateMapping, allLessons };
                });
                const { dateMapping, allLessons } = allLessonsData;
                console.log(`Found ${allLessons.length} total lessons for ${studioCode} across ${dateMapping.length} dates`);
                // Convert to our LessonData format
                const lessonData = allLessons.map((lesson) => ({
                    studioCode,
                    lessonDateTime: `${lesson.date}T${lesson.startTime}:00+09:00`,
                    lessonDate: lesson.date,
                    startTime: lesson.startTime,
                    endTime: lesson.endTime,
                    lessonName: lesson.lessonName,
                    instructor: lesson.instructor,
                    availableSlots: lesson.statusText ? this.extractAvailableSlots(lesson.statusText) : null,
                    totalSlots: null,
                    isAvailable: lesson.isAvailable ? 'true' : 'false',
                    program: lesson.program,
                    backgroundColor: lesson.backgroundColor || null,
                    textColor: lesson.textColor || null,
                    lastUpdated: (0, dateUtils_1.getJSTISOString)(),
                    ttl: (0, dateUtils_1.getTTLFromJST)(7), // 7 days from JST
                }));
                console.log(`✅ Successfully fetched ${lessonData.length} lessons for ${studioCode}`);
                return lessonData;
            }
            catch (error) {
                console.error(`❌ Attempt ${retryCount + 1} failed for ${studioCode}:`, error);
                // Close page if it exists
                if (page) {
                    try {
                        await page.close();
                    }
                    catch (closeError) {
                        console.error('Error closing page:', closeError);
                    }
                }
                retryCount++;
                if (retryCount > maxRetries) {
                    console.error(`❌ All ${maxRetries + 1} attempts failed for ${studioCode}`);
                    throw new Error(`Failed to fetch lessons for ${studioCode} after ${maxRetries + 1} attempts: ${error instanceof Error ? error.message : 'Unknown error'}`);
                }
                // Wait before retry
                const waitTime = retryCount * 2000; // 2s, 4s, etc.
                console.log(`⏳ Waiting ${waitTime}ms before retry...`);
                await new Promise(resolve => setTimeout(resolve, waitTime));
            }
        }
        // This should never be reached due to the throw in the catch block
        throw new Error(`Failed to fetch lessons for ${studioCode} after retries`);
    }
    /**
     * Search for lesson data for a specific studio and date (compatibility method)
     * This method now uses the optimized approach - gets all lessons and filters by date
     */
    static async searchRealLessons(studioCode, date) {
        console.log(`Fetching lessons for ${studioCode} on ${date} using optimized approach...`);
        // Get all lessons for the studio
        const allLessons = await this.searchAllLessons(studioCode);
        // Filter lessons for the specific date
        const filteredLessons = allLessons.filter(lesson => lesson.lessonDate === date);
        console.log(`Found ${filteredLessons.length} lessons for ${studioCode} on ${date} (from ${allLessons.length} total)`);
        return filteredLessons;
    }
    /**
     * Search for lessons from all studios for a specific date
     */
    static async searchAllStudiosRealLessons(date) {
        console.log(`🌏 Fetching lessons from ALL studios for ${date}...`);
        try {
            // First get all available studios
            const studios = await this.getRealStudios();
            console.log(`Found ${studios.length} studios to scrape`);
            const allLessons = [];
            // Process studios in batches to avoid overwhelming the site
            const batchSize = 5;
            for (let i = 0; i < studios.length; i += batchSize) {
                const batch = studios.slice(i, i + batchSize);
                console.log(`Processing studio batch ${Math.floor(i / batchSize) + 1}/${Math.ceil(studios.length / batchSize)}...`);
                const batchPromises = batch.map(async (studio) => {
                    try {
                        const lessons = await this.searchRealLessons(studio.code, date);
                        console.log(`${studio.name}(${studio.code}): ${lessons.length} lessons`);
                        return lessons;
                    }
                    catch (error) {
                        console.error(`Error scraping ${studio.name}(${studio.code}):`, error);
                        return [];
                    }
                });
                const batchResults = await Promise.all(batchPromises);
                batchResults.forEach(lessons => allLessons.push(...lessons));
                // Small delay between batches
                if (i + batchSize < studios.length) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }
            console.log(`✅ Total lessons found across all studios: ${allLessons.length}`);
            return allLessons;
        }
        catch (error) {
            console.error('Error in searchAllStudiosRealLessons:', error);
            throw error;
        }
    }
    /**
     * Extract available slots from status text
     */
    static extractAvailableSlots(statusText) {
        const match = statusText.match(/残り(\d+)人/);
        return match ? parseInt(match[1]) : 5;
    }
    /**
     * Cleanup browser resources and force garbage collection
     */
    static async cleanup() {
        if (this.browser) {
            console.log('🧹 Cleaning up browser resources...');
            try {
                // Close all pages first
                const pages = await this.browser.pages();
                await Promise.all(pages.map((page) => page.close().catch((e) => console.log('Page close error:', e))));
                // Close browser
                await this.browser.close();
                console.log('✅ Browser closed successfully');
            }
            catch (error) {
                console.error('⚠️  Error during browser cleanup:', error);
                // Force process termination if browser is unresponsive
                try {
                    if (this.browser && this.browser.process) {
                        this.browser.process().kill('SIGKILL');
                    }
                }
                catch (killError) {
                    console.error('Error killing browser process:', killError);
                }
            }
            finally {
                this.browser = null;
            }
            // Force garbage collection if available
            if (typeof global !== 'undefined' && global.gc) {
                console.log('🗑️  Running garbage collection...');
                global.gc();
            }
        }
    }
}
exports.RealFeelcycleScraper = RealFeelcycleScraper;
