import { Handler, SQSEvent } from 'aws-lambda';
interface BatchItemFailure {
    itemIdentifier: string;
}
interface WorkerResponse {
    batchItemFailures: BatchItemFailure[];
}
/**
 * Scraping Worker Lambda Function
 *
 * 役割:
 * 1. SQSメッセージからスタジオ情報を取得
 * 2. 該当スタジオのスクレイピング実行
 * 3. レッスンデータをDynamoDBに保存
 * 4. バッチ処理状況を更新
 * 5. エラー時の適切なハンドリング
 */
export declare const handler: Handler<SQSEvent, WorkerResponse>;
export {};
