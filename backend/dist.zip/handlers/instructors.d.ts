import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Instructors API Handler
 * GET /instructors - Get all instructors or filter by category
 * GET /instructors/{id} - Get specific instructor
 */
export declare function instructorsHandler(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
export declare const handler: typeof instructorsHandler;
