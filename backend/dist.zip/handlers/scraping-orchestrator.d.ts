import { Handler, EventBridgeEvent } from 'aws-lambda';
interface OrchestrationResult {
    success: boolean;
    batchId: string;
    studiosQueued: number;
    studiosSkipped: number;
    errors: string[];
    queueUrl: string;
    estimatedProcessingTime: string;
}
/**
 * Daily Scraping Orchestrator
 *
 * 役割:
 * 1. 全スタジオリストを取得
 * 2. 各スタジオをSQSキューに投入
 * 3. バッチ処理状況をDynamoDBで初期化
 * 4. 監視用メトリクス出力
 */
export declare const handler: Handler<EventBridgeEvent<string, any>, OrchestrationResult>;
export {};
