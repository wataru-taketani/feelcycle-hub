import { LambdaEvent, ApiResponse } from '../types';
/**
 * Programs API Handler
 * Handles program color information requests
 */
export declare const programsHandler: (event: LambdaEvent) => Promise<ApiResponse>;
