/**
 * 日本時間(JST)専用の日時ユーティリティ (Backend)
 * Lambda環境(UTC)で正確な日本時間を扱うためのユーティリティ
 */
/**
 * 現在の日本時間を取得
 */
export declare function getJST(): Date;
/**
 * 日本時間の今日の日付を YYYY-MM-DD 形式で取得
 */
export declare function getTodayJST(): string;
/**
 * 日本時間で指定日数後の日付を YYYY-MM-DD 形式で取得
 */
export declare function getDateAfterDaysJST(days: number): string;
/**
 * 現在の日本時間を ISO 文字列で取得 (タイムスタンプ用)
 */
export declare function getJSTISOString(): string;
/**
 * TTL用のUnixタイムスタンプを生成 (日本時間基準)
 * @param daysFromNow 何日後のTTLにするか
 */
export declare function getTTLFromJST(daysFromNow: number): number;
/**
 * 日付文字列がJST基準で今日以降かチェック
 */
export declare function isDateTodayOrFutureJST(dateString: string): boolean;
/**
 * 現在のJST時刻情報をログ出力 (デバッグ用)
 */
export declare function logJSTInfo(label?: string): void;
