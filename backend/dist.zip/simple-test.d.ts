import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare function simpleTest(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
