"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstructorsService = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dateUtils_1 = require("../utils/dateUtils");
class InstructorsService {
    dynamoClient;
    tableName;
    constructor() {
        const client = new client_dynamodb_1.DynamoDBClient({
            region: process.env.AWS_REGION || 'ap-northeast-1',
        });
        this.dynamoClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
        this.tableName = process.env.INSTRUCTORS_TABLE || 'feelcycle-hub-instructors-dev';
    }
    /**
     * Save instructor data to DynamoDB
     */
    async saveInstructor(instructorData) {
        const currentTime = (0, dateUtils_1.getJSTISOString)();
        const ttl = (0, dateUtils_1.getTTLFromJST)(90); // 90 days TTL
        const instructor = {
            ...instructorData,
            createdAt: currentTime,
            updatedAt: currentTime,
            ttl,
        };
        const command = new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: instructor,
        });
        await this.dynamoClient.send(command);
        console.log(`✅ Saved instructor: ${instructor.name} (${instructor.instructorId})`);
        return instructor;
    }
    /**
     * Get instructor by ID
     */
    async getInstructor(instructorId) {
        const command = new lib_dynamodb_1.GetCommand({
            TableName: this.tableName,
            Key: { instructorId },
        });
        const result = await this.dynamoClient.send(command);
        return result.Item || null;
    }
    /**
     * Get all instructors
     */
    async getAllInstructors() {
        const command = new lib_dynamodb_1.ScanCommand({
            TableName: this.tableName,
        });
        const result = await this.dynamoClient.send(command);
        return result.Items || [];
    }
    /**
     * Get instructors by category (A-Z)
     */
    async getInstructorsByCategory(category) {
        const command = new lib_dynamodb_1.ScanCommand({
            TableName: this.tableName,
            FilterExpression: 'category = :category',
            ExpressionAttributeValues: {
                ':category': category,
            },
        });
        const result = await this.dynamoClient.send(command);
        return result.Items || [];
    }
    /**
     * Batch save multiple instructors (used for scraping results)
     */
    async batchSaveInstructors(instructors) {
        const batchSize = 25; // DynamoDB batch write limit
        for (let i = 0; i < instructors.length; i += batchSize) {
            const batch = instructors.slice(i, i + batchSize);
            const putRequests = batch.map(instructor => ({
                PutRequest: {
                    Item: instructor,
                },
            }));
            const command = new lib_dynamodb_1.BatchWriteCommand({
                RequestItems: {
                    [this.tableName]: putRequests,
                },
            });
            await this.dynamoClient.send(command);
            console.log(`✅ Batch saved ${batch.length} instructors (${i + 1}-${i + batch.length})`);
        }
    }
    /**
     * Update instructor data
     */
    async updateInstructor(instructorId, updates) {
        const existingInstructor = await this.getInstructor(instructorId);
        if (!existingInstructor) {
            return null;
        }
        const currentTime = (0, dateUtils_1.getJSTISOString)();
        const updatedInstructor = {
            ...existingInstructor,
            ...updates,
            updatedAt: currentTime,
        };
        const command = new lib_dynamodb_1.UpdateCommand({
            TableName: this.tableName,
            Key: { instructorId },
            UpdateExpression: 'SET #name = :name, category = :category, updatedAt = :updatedAt',
            ExpressionAttributeNames: {
                '#name': 'name',
            },
            ExpressionAttributeValues: {
                ':name': updatedInstructor.name,
                ':category': updatedInstructor.category,
                ':updatedAt': currentTime,
            },
            ReturnValues: 'ALL_NEW',
        });
        const result = await this.dynamoClient.send(command);
        return result.Attributes;
    }
}
exports.InstructorsService = InstructorsService;
