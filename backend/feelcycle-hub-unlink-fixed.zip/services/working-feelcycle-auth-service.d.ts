/**
 * 動作確認済みFEELCYCLE認証サービス
 * WindSurfの成功実装をTypeScript + Lambda環境に適応
 */
interface LoginResult {
    success: boolean;
    url?: string;
    message?: string;
    error?: string;
    userInfo?: any;
}
/**
 * シンプル・確実なFEELCYCLEログイン機能
 * @param email FEELCYCLEメールアドレス
 * @param password FEELCYCLEパスワード
 */
export declare function verifyFeelcycleLogin(email: string, password: string): Promise<LoginResult>;
/**
 * 既存システムとの互換性のためのラッパー
 */
export declare function authenticateFeelcycleAccountWorking(userId: string, email: string, password: string): Promise<{
    success: boolean;
    data: {
        homeStudio: string;
        membershipType: string;
        currentReservations: never[];
        connectedAt: string;
    };
}>;
export {};
