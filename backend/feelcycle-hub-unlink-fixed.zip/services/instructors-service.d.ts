export interface InstructorData {
    instructorId: string;
    name: string;
    category: string;
    studioCode?: string;
    createdAt?: string;
    updatedAt?: string;
    ttl?: number;
}
export declare class InstructorsService {
    private dynamoClient;
    private tableName;
    constructor();
    /**
     * Save instructor data to DynamoDB
     */
    saveInstructor(instructorData: InstructorData): Promise<InstructorData>;
    /**
     * Get instructor by ID
     */
    getInstructor(instructorId: string): Promise<InstructorData | null>;
    /**
     * Get all instructors
     */
    getAllInstructors(): Promise<InstructorData[]>;
    /**
     * Get instructors by category (A-Z)
     */
    getInstructorsByCategory(category: string): Promise<InstructorData[]>;
    /**
     * Batch save multiple instructors (used for scraping results)
     */
    batchSaveInstructors(instructors: InstructorData[]): Promise<void>;
    /**
     * Update instructor data
     */
    updateInstructor(instructorId: string, updates: Partial<InstructorData>): Promise<InstructorData | null>;
}
