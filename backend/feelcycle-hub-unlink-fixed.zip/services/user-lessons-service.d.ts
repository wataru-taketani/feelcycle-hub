export interface UserLessonRecord {
    PK: string;
    SK: string;
    userId: string;
    studioCode: string;
    lessonDate: string;
    startTime: string;
    lessonName: string;
    instructor: string;
    type: 'favorite' | 'waitlist' | 'booking' | 'history';
    status: 'active' | 'completed' | 'cancelled' | 'expired';
    createdAt: string;
    updatedAt: string;
    ttl?: number;
    lessonDateTime?: string;
    waitlistId?: string;
    notificationSent?: boolean;
    reservationId?: string;
    notes?: string;
}
export declare class UserLessonsService {
    private tableName;
    constructor();
    /**
     * 気になるリストに追加
     */
    addToFavorites(userId: string, lessonInfo: {
        studioCode: string;
        lessonDate: string;
        startTime: string;
        lessonName: string;
        instructor: string;
        notes?: string;
    }): Promise<UserLessonRecord>;
    /**
     * キャンセル待ちに追加
     */
    addToWaitlist(userId: string, lessonInfo: {
        studioCode: string;
        lessonDate: string;
        startTime: string;
        lessonName: string;
        instructor: string;
        waitlistId: string;
        ttlDays?: number;
    }): Promise<UserLessonRecord>;
    /**
     * ユーザーの特定タイプのレッスン関係を取得
     */
    getUserLessonsByType(userId: string, type: UserLessonRecord['type']): Promise<UserLessonRecord[]>;
    /**
     * アクティブなキャンセル待ちを取得（監視用）
     */
    getActiveWaitlists(): Promise<UserLessonRecord[]>;
    /**
     * レッスン関係を削除
     */
    removeUserLesson(userId: string, studioCode: string, lessonDate: string, startTime: string, type: UserLessonRecord['type']): Promise<void>;
    /**
     * ステータス更新
     */
    updateStatus(userId: string, studioCode: string, lessonDate: string, startTime: string, type: UserLessonRecord['type'], status: UserLessonRecord['status']): Promise<void>;
    /**
     * 通知送信済みマーク
     */
    markNotificationSent(userId: string, studioCode: string, lessonDate: string, startTime: string): Promise<void>;
}
