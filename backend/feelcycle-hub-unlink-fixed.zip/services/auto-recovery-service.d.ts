/**
 * 自動復旧サービス
 * 本番運用でのエラー発生時に人間の介入なしで自動復旧を実行
 */
export interface RecoveryResult {
    success: boolean;
    action: string;
    details: string;
    recoveryTime: number;
    fallbackUsed: boolean;
    nextRetryAt?: string;
}
export interface RecoveryContext {
    errorType: string;
    errorMessage: string;
    failedOperation: string;
    retryCount: number;
    lastSuccessTime?: string;
    systemState: 'normal' | 'degraded' | 'critical';
}
export declare class AutoRecoveryService {
    private static instance;
    private recoveryInProgress;
    private maxRetryAttempts;
    private baseRetryDelay;
    static getInstance(): AutoRecoveryService;
    /**
     * メイン復旧エントリーポイント
     */
    attemptRecovery(context: RecoveryContext): Promise<RecoveryResult>;
    /**
     * エラータイプ別復旧戦略の実行
     */
    private executeRecoveryStrategy;
    /**
     * スタジオスクレイピング失敗の復旧
     */
    private recoverStudioScrapingFailure;
    /**
     * データベース接続失敗の復旧
     */
    private recoverDatabaseConnectionFailure;
    /**
     * ブラウザ初期化失敗の復旧
     */
    private recoverBrowserInitializationFailure;
    /**
     * スタジオ更新失敗の復旧
     */
    private recoverStudioUpdateFailure;
    /**
     * レッスン保存失敗の復旧
     */
    private recoverLessonStorageFailure;
    /**
     * バッチ処理停止の復旧
     */
    private recoverBatchProcessingStuck;
    /**
     * 汎用復旧戦略
     */
    private executeGenericRecovery;
    private extractStudioCodeFromError;
    private attemptPartialStudioUpdate;
    private findStuckProcessingStudios;
    /**
     * 復旧成功後のシステム状態確認
     */
    verifySystemHealth(): Promise<{
        healthy: boolean;
        checks: Record<string, boolean>;
        details: string[];
    }>;
}
export declare const autoRecoveryService: AutoRecoveryService;
