/**
 * FEELCYCLE認証サービスのセキュリティテスト
 *
 * このファイルは防御的セキュリティ目的で作成され、
 * 脆弱性の検出と修正確認を行います。
 */
/**
 * セキュリティテスト関数
 */
export declare function runSecurityTests(): {
    passed: number;
    failed: number;
    details: string[];
};
/**
 * レート制限テストのシミュレーション
 */
export declare function testRateLimiting(): {
    passed: number;
    failed: number;
    details: string[];
};
export declare function runAllSecurityTests(): void;
