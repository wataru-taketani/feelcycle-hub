"use strict";
/**
 * FEELCYCLE 統合機能の型定義
 */
Object.defineProperty(exports, "__esModule", { value: true });
