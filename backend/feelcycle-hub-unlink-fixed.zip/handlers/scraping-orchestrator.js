"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Environment variables
const STUDIOS_TABLE_NAME = process.env.STUDIOS_TABLE_NAME;
const BATCH_STATUS_TABLE_NAME = process.env.BATCH_STATUS_TABLE_NAME;
const SCRAPING_QUEUE_URL = process.env.SCRAPING_QUEUE_URL;
const AWS_REGION = process.env.AWS_REGION || 'ap-northeast-1';
// AWS clients
const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: AWS_REGION });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const sqsClient = new client_sqs_1.SQSClient({ region: AWS_REGION });
/**
 * Daily Scraping Orchestrator
 *
 * 役割:
 * 1. 全スタジオリストを取得
 * 2. 各スタジオをSQSキューに投入
 * 3. バッチ処理状況をDynamoDBで初期化
 * 4. 監視用メトリクス出力
 */
const handler = async (event, context) => {
    console.log('🚀 Daily Scraping Orchestrator Started');
    console.log('Event:', JSON.stringify(event, null, 2));
    const startTime = Date.now();
    const batchId = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const originalTimestamp = new Date().toISOString();
    const result = {
        success: false,
        batchId,
        studiosQueued: 0,
        studiosSkipped: 0,
        errors: [],
        queueUrl: SCRAPING_QUEUE_URL,
        estimatedProcessingTime: '未計算',
    };
    try {
        console.log(`📊 Batch ID: ${batchId}`);
        console.log(`🔗 Queue URL: ${SCRAPING_QUEUE_URL}`);
        // Step 1: Get all active studios
        console.log('\n📍 Step 1: Fetching active studios...');
        const studios = await getAllActiveStudios();
        console.log(`✅ Found ${studios.length} active studios`);
        if (studios.length === 0) {
            throw new Error('No active studios found in database');
        }
        // Step 2: Check for existing batch (prevent duplicate runs)
        console.log('\n📍 Step 2: Checking for existing batch...');
        const existingBatch = await checkExistingBatch(batchId);
        if (existingBatch.length > 0) {
            const completedCount = existingBatch.filter(b => b.status === 'completed').length;
            const pendingCount = existingBatch.filter(b => b.status === 'pending').length;
            const processingCount = existingBatch.filter(b => b.status === 'processing').length;
            console.log(`⚠️  Existing batch found: ${completedCount} completed, ${processingCount} processing, ${pendingCount} pending`);
            if (pendingCount === 0 && processingCount === 0) {
                console.log('🎉 Previous batch completed, starting fresh batch');
                await clearBatchStatus(batchId);
            }
            else {
                console.log('🔄 Previous batch still running, adding missing studios only');
                const existingStudioCodes = new Set(existingBatch.map(b => b.studioCode));
                const missingStudios = studios.filter(s => !existingStudioCodes.has(s.studioCode));
                if (missingStudios.length > 0) {
                    console.log(`📝 Adding ${missingStudios.length} missing studios to existing batch`);
                    await queueStudiosForScraping(missingStudios, batchId, originalTimestamp, result);
                }
                else {
                    console.log('✅ All studios already in queue, no action needed');
                }
                result.success = true;
                return result;
            }
        }
        // Step 3: Queue all studios for scraping
        console.log('\n📍 Step 3: Queuing studios for scraping...');
        await queueStudiosForScraping(studios, batchId, originalTimestamp, result);
        // Step 4: Initialize batch status tracking
        console.log('\n📍 Step 4: Initializing batch status tracking...');
        await initializeBatchStatus(studios, batchId);
        // Step 5: Calculate and log estimated processing time
        const estimatedTime = calculateEstimatedProcessingTime(studios.length);
        result.estimatedProcessingTime = estimatedTime;
        console.log('\n🎉 Orchestration completed successfully!');
        console.log(`📊 Final Results:`);
        console.log(`   • Studios queued: ${result.studiosQueued}`);
        console.log(`   • Studios skipped: ${result.studiosSkipped}`);
        console.log(`   • Errors: ${result.errors.length}`);
        console.log(`   • Estimated processing time: ${estimatedTime}`);
        console.log(`   • Queue URL: ${SCRAPING_QUEUE_URL}`);
        if (result.errors.length > 0) {
            console.warn('⚠️  Errors encountered:');
            result.errors.forEach((error, index) => {
                console.warn(`   ${index + 1}. ${error}`);
            });
        }
        // Step 6: Verify queue status
        await verifyQueueStatus();
        result.success = true;
        return result;
    }
    catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        console.error('❌ Orchestration failed:', errorMessage);
        result.errors.push(`Orchestration failed: ${errorMessage}`);
        result.success = false;
        // Emergency fallback - trigger legacy progressive refresh if available
        try {
            console.log('🚨 Attempting fallback to legacy progressive refresh...');
            // TODO: Implement fallback mechanism
            console.log('⚠️  Fallback mechanism not implemented yet');
        }
        catch (fallbackError) {
            console.error('❌ Fallback also failed:', fallbackError);
        }
        throw error;
    }
    finally {
        const endTime = Date.now();
        const duration = (endTime - startTime) / 1000;
        console.log(`\n⏱️  Orchestration duration: ${duration.toFixed(2)} seconds`);
        // Report memory usage
        const memUsage = process.memoryUsage();
        console.log(`💾 Memory usage: ${Math.round(memUsage.heapUsed / 1024 / 1024)}MB used`);
    }
};
exports.handler = handler;
/**
 * Get all active studios from DynamoDB
 */
async function getAllActiveStudios() {
    try {
        const response = await docClient.send(new lib_dynamodb_1.ScanCommand({
            TableName: STUDIOS_TABLE_NAME,
            ConsistentRead: true,
        }));
        const studios = (response.Items || []);
        // Filter out inactive or invalid studios
        const activeStudios = studios.filter(studio => studio.studioCode &&
            studio.studioName &&
            studio.studioCode.length >= 2 &&
            studio.studioCode.length <= 5);
        console.log(`📊 Total studios in DB: ${studios.length}, Active: ${activeStudios.length}`);
        return activeStudios.sort((a, b) => a.studioCode.localeCompare(b.studioCode));
    }
    catch (error) {
        console.error('❌ Failed to fetch studios:', error);
        throw new Error(`Failed to fetch studios: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
}
/**
 * Check for existing batch status
 */
async function checkExistingBatch(batchId) {
    try {
        const response = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: BATCH_STATUS_TABLE_NAME,
            KeyConditionExpression: 'batchId = :batchId',
            ExpressionAttributeValues: {
                ':batchId': batchId,
            },
        }));
        return (response.Items || []);
    }
    catch (error) {
        console.warn('⚠️  Failed to check existing batch (table may not exist):', error);
        return [];
    }
}
/**
 * Clear existing batch status
 */
async function clearBatchStatus(batchId) {
    try {
        const existingItems = await checkExistingBatch(batchId);
        if (existingItems.length > 0) {
            console.log(`🗑️  Clearing ${existingItems.length} existing batch status records`);
            // Note: In production, consider using BatchWriteItem for better performance
            for (const item of existingItems) {
                await docClient.send(new client_dynamodb_1.DynamoDBClient({}).send({})); // Delete operation placeholder
                // TODO: Implement actual delete operation
            }
        }
    }
    catch (error) {
        console.warn('⚠️  Failed to clear batch status:', error);
        // Non-critical error, continue processing
    }
}
/**
 * Queue studios for scraping
 */
async function queueStudiosForScraping(studios, batchId, originalTimestamp, result) {
    const batchSize = 10; // SQS batch size limit
    const studioBatches = [];
    // Split studios into batches for efficient SQS operations
    for (let i = 0; i < studios.length; i += batchSize) {
        studioBatches.push(studios.slice(i, i + batchSize));
    }
    console.log(`📦 Processing ${studioBatches.length} batches of studios`);
    for (let batchIndex = 0; batchIndex < studioBatches.length; batchIndex++) {
        const studioBatch = studioBatches[batchIndex];
        console.log(`📦 Processing batch ${batchIndex + 1}/${studioBatches.length} (${studioBatch.length} studios)`);
        for (const studio of studioBatch) {
            try {
                const message = {
                    batchId,
                    studioCode: studio.studioCode,
                    studioName: studio.studioName,
                    taskType: 'daily-scraping',
                    priority: determinePriority(studio),
                    retryCount: 0,
                    originalTimestamp,
                    region: studio.region,
                };
                await sqsClient.send(new client_sqs_1.SendMessageCommand({
                    QueueUrl: SCRAPING_QUEUE_URL,
                    MessageBody: JSON.stringify(message),
                    MessageGroupId: studio.region || 'default', // For FIFO queues if needed
                    MessageDeduplicationId: `${batchId}-${studio.studioCode}`, // Prevent duplicates
                }));
                result.studiosQueued++;
                console.log(`✅ Queued: ${studio.studioName} (${studio.studioCode})`);
            }
            catch (error) {
                const errorMessage = `Failed to queue ${studio.studioName}: ${error instanceof Error ? error.message : 'Unknown error'}`;
                console.error(`❌ ${errorMessage}`);
                result.errors.push(errorMessage);
                result.studiosSkipped++;
            }
        }
        // Small delay between batches to avoid overwhelming SQS
        if (batchIndex < studioBatches.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }
    }
    console.log(`📊 Queuing complete: ${result.studiosQueued} queued, ${result.studiosSkipped} skipped`);
}
/**
 * Initialize batch status tracking
 */
async function initializeBatchStatus(studios, batchId) {
    console.log(`📝 Initializing batch status for ${studios.length} studios`);
    try {
        for (const studio of studios) {
            const batchStatus = {
                batchId,
                studioCode: studio.studioCode,
                status: 'pending',
                retryCount: 0,
            };
            await docClient.send(new lib_dynamodb_1.PutCommand({
                TableName: BATCH_STATUS_TABLE_NAME,
                Item: batchStatus,
                ConditionExpression: 'attribute_not_exists(batchId) AND attribute_not_exists(studioCode)',
            }));
        }
        console.log('✅ Batch status initialization completed');
    }
    catch (error) {
        console.warn('⚠️  Some batch status records may already exist:', error);
        // Non-critical error for orchestrator
    }
}
/**
 * Determine processing priority for studio
 */
function determinePriority(studio) {
    // High priority for major studios
    const highPriorityStudios = ['sjk', 'gnz', 'sby', 'ikb']; // 新宿、銀座、渋谷、恵比寿
    if (highPriorityStudios.includes(studio.studioCode.toLowerCase())) {
        return 'high';
    }
    // Low priority for smaller studios
    const lowPriorityStudios = ['kch', 'nab']; // 例: 吉祥寺、成増
    if (lowPriorityStudios.includes(studio.studioCode.toLowerCase())) {
        return 'low';
    }
    return 'normal';
}
/**
 * Calculate estimated processing time
 */
function calculateEstimatedProcessingTime(studioCount) {
    // 並列処理を考慮した計算
    const maxConcurrentWorkers = 10;
    const avgProcessingTimePerStudio = 12; // seconds
    const parallelGroups = Math.ceil(studioCount / maxConcurrentWorkers);
    const estimatedSeconds = parallelGroups * avgProcessingTimePerStudio;
    if (estimatedSeconds < 60) {
        return `${estimatedSeconds}秒`;
    }
    else if (estimatedSeconds < 3600) {
        const minutes = Math.ceil(estimatedSeconds / 60);
        return `${minutes}分`;
    }
    else {
        const hours = Math.floor(estimatedSeconds / 3600);
        const minutes = Math.ceil((estimatedSeconds % 3600) / 60);
        return `${hours}時間${minutes}分`;
    }
}
/**
 * Verify queue status after orchestration
 */
async function verifyQueueStatus() {
    try {
        const response = await sqsClient.send(new client_sqs_1.GetQueueAttributesCommand({
            QueueUrl: SCRAPING_QUEUE_URL,
            AttributeNames: ['All'],
        }));
        const attributes = response.Attributes || {};
        const visibleMessages = parseInt(attributes.ApproximateNumberOfMessages || '0');
        const inFlightMessages = parseInt(attributes.ApproximateNumberOfMessagesNotVisible || '0');
        console.log(`\n📊 Queue Status Verification:`);
        console.log(`   • Visible messages: ${visibleMessages}`);
        console.log(`   • In-flight messages: ${inFlightMessages}`);
        console.log(`   • Total messages: ${visibleMessages + inFlightMessages}`);
        if (visibleMessages === 0 && inFlightMessages === 0) {
            console.warn('⚠️  No messages in queue - this may indicate a problem');
        }
    }
    catch (error) {
        console.warn('⚠️  Failed to verify queue status:', error);
    }
}
