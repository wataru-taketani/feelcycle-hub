"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const instructor_scraper_1 = require("../services/instructor-scraper");
const instructors_service_1 = require("../services/instructors-service");
/**
 * Monthly Instructor Scraper Handler
 * Triggered by EventBridge on the first day of each month
 */
async function handler(event) {
    console.log('🗓️ Monthly instructor scraper started');
    console.log('Event:', JSON.stringify(event, null, 2));
    const instructorsService = new instructors_service_1.InstructorsService();
    try {
        // Step 1: Scrape all instructors from FEELCYCLE website
        console.log('📥 Starting instructor scraping...');
        const scrapedInstructors = await instructor_scraper_1.InstructorScraper.scrapeAllInstructors();
        if (scrapedInstructors.length === 0) {
            console.warn('⚠️ No instructors scraped');
            return {
                success: false,
                error: 'No instructors found during scraping',
            };
        }
        console.log(`✅ Successfully scraped ${scrapedInstructors.length} instructors`);
        // Step 2: Clear existing instructor data to ensure fresh data
        console.log('🗑️ Clearing existing instructor data...');
        await instructorsService.clearAllInstructors();
        // Step 3: Save new instructor data to DynamoDB
        console.log('💾 Saving new instructor data...');
        await instructorsService.batchSaveInstructors(scrapedInstructors);
        // Step 4: Verify saved data
        const savedInstructors = await instructorsService.getAllInstructors();
        console.log(`✅ Verification: ${savedInstructors.length} instructors saved in database`);
        // Generate summary by category
        const categoryStats = {};
        scrapedInstructors.forEach(instructor => {
            categoryStats[instructor.category] = (categoryStats[instructor.category] || 0) + 1;
        });
        const summary = {
            totalInstructors: scrapedInstructors.length,
            categoriesCount: Object.keys(categoryStats).length,
            categoryBreakdown: categoryStats,
            scrapedAt: new Date().toISOString(),
        };
        console.log('📊 Scraping Summary:', JSON.stringify(summary, null, 2));
        return {
            success: true,
            data: summary,
            message: `Successfully scraped and saved ${scrapedInstructors.length} instructors`,
        };
    }
    catch (error) {
        console.error('❌ Monthly instructor scraping failed:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error occurred',
            message: 'Monthly instructor scraping failed',
        };
    }
    finally {
        // Cleanup browser resources
        try {
            await instructor_scraper_1.InstructorScraper.cleanup();
            console.log('🧹 Browser cleanup completed');
        }
        catch (cleanupError) {
            console.error('⚠️ Browser cleanup error:', cleanupError);
        }
    }
}
