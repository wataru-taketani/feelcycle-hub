"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const real_scraper_1 = require("../services/real-scraper");
const lessons_service_1 = require("../services/lessons-service");
// Environment variables
const STUDIOS_TABLE_NAME = process.env.STUDIOS_TABLE_NAME;
const LESSONS_TABLE_NAME = process.env.LESSONS_TABLE_NAME;
const BATCH_STATUS_TABLE_NAME = process.env.BATCH_STATUS_TABLE_NAME;
const AWS_REGION = process.env.AWS_REGION || 'ap-northeast-1';
// AWS clients
const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: AWS_REGION });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
/**
 * Scraping Worker Lambda Function
 *
 * 役割:
 * 1. SQSメッセージからスタジオ情報を取得
 * 2. 該当スタジオのスクレイピング実行
 * 3. レッスンデータをDynamoDBに保存
 * 4. バッチ処理状況を更新
 * 5. エラー時の適切なハンドリング
 */
const handler = async (event, context) => {
    console.log('🔧 Scraping Worker Started');
    console.log(`📨 Processing ${event.Records.length} messages`);
    const startTime = Date.now();
    const workerId = context.awsRequestId;
    const failures = [];
    const lessonService = new lessons_service_1.LessonsService();
    try {
        // Process each SQS message (typically 1 message = 1 studio)
        for (const record of event.Records) {
            const result = await processScrapingTask(record, workerId, lessonService);
            if (!result.success) {
                // Mark this message as failed for SQS retry
                failures.push({
                    itemIdentifier: record.messageId
                });
                console.error(`❌ Failed to process studio ${result.studioCode}: ${result.errorMessage}`);
            }
            else {
                console.log(`✅ Successfully processed ${result.studioName}: ${result.lessonsProcessed} lessons in ${result.duration.toFixed(2)}s`);
            }
        }
        console.log(`🎉 Worker completed: ${event.Records.length - failures.length}/${event.Records.length} successful`);
        return {
            batchItemFailures: failures
        };
    }
    catch (error) {
        console.error('❌ Worker failed with unhandled error:', error);
        // Mark all messages as failed if there's a systemic error
        const allFailures = event.Records.map(record => ({
            itemIdentifier: record.messageId
        }));
        return {
            batchItemFailures: allFailures
        };
    }
    finally {
        // Cleanup resources
        await real_scraper_1.RealFeelcycleScraper.cleanup();
        const endTime = Date.now();
        const totalDuration = (endTime - startTime) / 1000;
        console.log(`⏱️  Worker execution time: ${totalDuration.toFixed(2)} seconds`);
        // Report memory usage
        const memUsage = process.memoryUsage();
        console.log(`💾 Worker memory usage: ${Math.round(memUsage.heapUsed / 1024 / 1024)}MB used`);
    }
};
exports.handler = handler;
/**
 * Process individual scraping task
 */
async function processScrapingTask(record, workerId, lessonService) {
    const taskStartTime = Date.now();
    try {
        // Parse SQS message
        const message = JSON.parse(record.body);
        console.log(`\n🎯 Processing: ${message.studioName} (${message.studioCode})`);
        console.log(`📊 Task details: batch=${message.batchId}, priority=${message.priority}, retry=${message.retryCount}`);
        const result = {
            success: false,
            studioCode: message.studioCode,
            studioName: message.studioName,
            lessonsProcessed: 0,
            duration: 0,
            retryCount: message.retryCount,
        };
        // Update batch status to processing
        await updateBatchStatus(message.batchId, message.studioCode, {
            status: 'processing',
            startedAt: new Date().toISOString(),
            workerLambdaId: workerId,
            retryCount: message.retryCount,
        });
        // Execute scraping for this studio
        console.log(`🔍 Starting scraping for ${message.studioName}...`);
        const scrapingStartTime = Date.now();
        const lessons = await real_scraper_1.RealFeelcycleScraper.searchAllLessons(message.studioCode);
        const scrapingEndTime = Date.now();
        const scrapingDuration = (scrapingEndTime - scrapingStartTime) / 1000;
        console.log(`📚 Scraped ${lessons.length} lessons in ${scrapingDuration.toFixed(2)}s`);
        if (lessons.length > 0) {
            // Save lessons to DynamoDB
            console.log(`💾 Saving ${lessons.length} lessons to database...`);
            const saveStartTime = Date.now();
            await lessonService.storeLessonsData(lessons);
            const saveEndTime = Date.now();
            const saveDuration = (saveEndTime - saveStartTime) / 1000;
            console.log(`✅ Saved lessons in ${saveDuration.toFixed(2)}s`);
            // Group lessons by date for reporting
            const lessonsByDate = lessons.reduce((acc, lesson) => {
                acc[lesson.lessonDate] = (acc[lesson.lessonDate] || 0) + 1;
                return acc;
            }, {});
            console.log(`📅 Lessons by date: ${Object.entries(lessonsByDate).map(([date, count]) => `${date}:${count}`).join(', ')}`);
            result.lessonsProcessed = lessons.length;
        }
        else {
            console.log(`⚠️  No lessons found for ${message.studioName}`);
        }
        // Calculate total duration
        const taskEndTime = Date.now();
        result.duration = (taskEndTime - taskStartTime) / 1000;
        // Update batch status to completed
        await updateBatchStatus(message.batchId, message.studioCode, {
            status: 'completed',
            completedAt: new Date().toISOString(),
            lessonsCount: lessons.length,
            scrapingDuration: result.duration,
        });
        result.success = true;
        console.log(`🎉 ${message.studioName} processing completed successfully`);
        return result;
    }
    catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        console.error(`❌ Error processing task:`, errorMessage);
        try {
            // Parse message for error reporting (fallback)
            const message = JSON.parse(record.body);
            // Update batch status to failed
            await updateBatchStatus(message.batchId, message.studioCode, {
                status: 'failed',
                completedAt: new Date().toISOString(),
                errorMessage: errorMessage,
                retryCount: message.retryCount,
            });
            const taskEndTime = Date.now();
            const duration = (taskEndTime - taskStartTime) / 1000;
            return {
                success: false,
                studioCode: message.studioCode,
                studioName: message.studioName,
                lessonsProcessed: 0,
                duration: duration,
                errorMessage: errorMessage,
                retryCount: message.retryCount,
            };
        }
        catch (parseError) {
            console.error('❌ Failed to parse message for error reporting:', parseError);
            return {
                success: false,
                studioCode: 'unknown',
                studioName: 'unknown',
                lessonsProcessed: 0,
                duration: 0,
                errorMessage: `Parse error: ${parseError instanceof Error ? parseError.message : 'Unknown error'}`,
                retryCount: 0,
            };
        }
    }
}
/**
 * Update batch status in DynamoDB
 */
async function updateBatchStatus(batchId, studioCode, updates) {
    try {
        // Build update expression dynamically
        const updateExpressionParts = [];
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        Object.entries(updates).forEach(([key, value]) => {
            if (value !== undefined) {
                const attributeName = `#${key}`;
                const attributeValue = `:${key}`;
                updateExpressionParts.push(`${attributeName} = ${attributeValue}`);
                expressionAttributeNames[attributeName] = key;
                expressionAttributeValues[attributeValue] = value;
            }
        });
        if (updateExpressionParts.length === 0) {
            console.warn('⚠️  No updates provided for batch status');
            return;
        }
        const updateExpression = `SET ${updateExpressionParts.join(', ')}`;
        await docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: BATCH_STATUS_TABLE_NAME,
            Key: {
                batchId: batchId,
                studioCode: studioCode,
            },
            UpdateExpression: updateExpression,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ConditionExpression: 'attribute_exists(batchId) AND attribute_exists(studioCode)',
        }));
        console.log(`📝 Updated batch status for ${studioCode}: ${JSON.stringify(updates)}`);
    }
    catch (error) {
        if (error instanceof Error && error.name === 'ConditionalCheckFailedException') {
            console.warn(`⚠️  Batch status record not found, creating new one for ${studioCode}`);
            // Create new batch status record
            const batchStatus = {
                batchId,
                studioCode,
                status: 'pending',
                retryCount: 0,
                ...updates,
            };
            try {
                await docClient.send(new lib_dynamodb_1.PutCommand({
                    TableName: BATCH_STATUS_TABLE_NAME,
                    Item: batchStatus,
                }));
                console.log(`📝 Created new batch status for ${studioCode}`);
            }
            catch (createError) {
                console.error(`❌ Failed to create batch status for ${studioCode}:`, createError);
            }
        }
        else {
            console.error(`❌ Failed to update batch status for ${studioCode}:`, error);
        }
    }
}
/**
 * Get current batch progress (optional utility function)
 */
async function getBatchProgress(batchId) {
    try {
        const response = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: BATCH_STATUS_TABLE_NAME,
            KeyConditionExpression: 'batchId = :batchId',
            ExpressionAttributeValues: {
                ':batchId': batchId,
            },
        }));
        const items = (response.Items || []);
        const total = items.length;
        const completed = items.filter(item => item.status === 'completed').length;
        const processing = items.filter(item => item.status === 'processing').length;
        const failed = items.filter(item => item.status === 'failed').length;
        const pending = items.filter(item => item.status === 'pending').length;
        return { total, completed, processing, failed, pending };
    }
    catch (error) {
        console.warn('⚠️  Failed to get batch progress:', error);
        return { total: 0, completed: 0, processing: 0, failed: 0, pending: 0 };
    }
}
