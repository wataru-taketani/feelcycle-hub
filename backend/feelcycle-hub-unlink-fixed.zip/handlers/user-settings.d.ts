import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * ユーザーお気に入り管理ハンドラー (/user/preferences/favorites)
 */
export declare function userSettingsHandler(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
