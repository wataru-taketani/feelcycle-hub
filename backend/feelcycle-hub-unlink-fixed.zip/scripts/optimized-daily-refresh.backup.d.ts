declare function optimizedDailyRefresh(): Promise<void>;
export { optimizedDailyRefresh };
