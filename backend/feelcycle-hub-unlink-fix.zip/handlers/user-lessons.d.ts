import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * User lessons API handler
 */
export declare function handler(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
