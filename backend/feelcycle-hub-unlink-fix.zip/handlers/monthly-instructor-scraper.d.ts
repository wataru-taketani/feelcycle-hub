import { LambdaEvent, ApiResponse } from '../types';
/**
 * Monthly Instructor Scraper Handler
 * Triggered by EventBridge on the first day of each month
 */
export declare function handler(event: LambdaEvent): Promise<ApiResponse>;
