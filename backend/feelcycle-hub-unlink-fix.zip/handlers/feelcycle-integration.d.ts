import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * FEELCYCLE アカウント連携実行
 * POST /api/feelcycle/integrate
 */
export declare function integrateAccount(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * FEELCYCLE 連携状態取得
 * GET /api/feelcycle/status/{userId}
 */
export declare function getIntegrationStatus(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
/**
 * FEELCYCLE 連携解除
 * DELETE /api/feelcycle/unlink/{userId}
 */
export declare function unlinkAccount(event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult>;
export { integrateAccount as integrate };
export { getIntegrationStatus as status };
export { unlinkAccount as unlink };
