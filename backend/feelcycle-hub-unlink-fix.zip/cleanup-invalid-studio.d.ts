/**
 * Clean up invalid studio code "0" from the studios table
 * This script removes the duplicate invalid entry for 自由が丘 (Jiyugaoka) studio
 */
declare function cleanupInvalidStudio(): Promise<void>;
export { cleanupInvalidStudio };
