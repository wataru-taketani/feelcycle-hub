/**
 * 既存のユーザーテーブルにFEELCYCLE連携フィールドを追加
 */
declare function updateUsersTableSchema(): Promise<void>;
export { updateUsersTableSchema };
