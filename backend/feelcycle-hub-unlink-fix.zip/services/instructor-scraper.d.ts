import { InstructorData } from '../types';
export declare class InstructorScraper {
    private static browser;
    /**
     * Initialize browser instance
     */
    static initBrowser(): Promise<any>;
    /**
     * Close browser instance
     */
    static closeBrowser(): Promise<void>;
    /**
     * Scrape all instructors from FEELCYCLE instructor index page
     */
    static scrapeAllInstructors(): Promise<InstructorData[]>;
    /**
     * Clean up resources
     */
    static cleanup(): Promise<void>;
}
