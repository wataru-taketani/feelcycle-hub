/**
 * バックグラウンド認証（保存済み認証情報を使用）
 * Windserf提案：復号機能の実装
 */
export declare function backgroundAuthenticateFeelcycleAccount(userId: string): Promise<{
    success: boolean;
    data?: any;
    error?: string;
}>;
export declare function authenticateFeelcycleAccountEnhanced(userId: string, email: string, password: string): Promise<{
    success: boolean;
    data: {
        homeStudio: any;
        membershipType: any;
        currentReservations: any;
        connectedAt: string;
    };
}>;
export declare function checkFeelcycleAccountStatusEnhanced(userId: string): Promise<{
    linked: boolean;
    data?: any;
}>;
export declare const authenticateFeelcycleAccount: typeof authenticateFeelcycleAccountEnhanced;
export declare const checkFeelcycleAccountStatus: typeof checkFeelcycleAccountStatusEnhanced;
