"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyFeelcycleLogin = verifyFeelcycleLogin;
exports.authenticateFeelcycleAccountWorking = authenticateFeelcycleAccountWorking;
const puppeteer = __importStar(require("puppeteer-core"));
// @ts-ignore
const chromium_1 = __importDefault(require("@sparticuz/chromium"));
/**
 * シンプル・確実なFEELCYCLEログイン機能
 * @param email FEELCYCLEメールアドレス
 * @param password FEELCYCLEパスワード
 */
async function verifyFeelcycleLogin(email, password) {
    console.log('🚀 シンプルFEELCYCLE認証開始');
    let browser = null;
    try {
        // WindSurfと同じシンプルなブラウザ起動（Lambda用は後で調整）
        const isLambda = !!process.env.AWS_LAMBDA_FUNCTION_NAME;
        if (isLambda) {
            // Lambda環境
            browser = await puppeteer.launch({
                args: [
                    ...chromium_1.default.args,
                    '--hide-scrollbars',
                    '--disable-web-security',
                ],
                defaultViewport: { width: 1280, height: 720 },
                executablePath: await chromium_1.default.executablePath(),
                headless: true,
            });
        }
        else {
            // ローカル環境: WindSurfと同じシンプル設定
            browser = await puppeteer.launch({
                headless: true,
                args: ['--no-sandbox', '--disable-setuid-sandbox']
            });
        }
        const page = await browser.newPage();
        // WindSurfと同じ処理流れ
        console.log('📱 ログインページアクセス中...');
        await page.goto('https://m.feelcycle.com/mypage/login', {
            waitUntil: 'networkidle2', // SPA対応の重要ポイント
            timeout: 60000
        });
        console.log('⏳ JavaScript読み込み待機中...');
        await page.waitForFunction(() => {
            return document.readyState === 'complete' &&
                document.querySelector('input[name="email"]') !== null;
        }, { timeout: 30000 });
        console.log('📝 ログイン情報入力中...');
        await page.waitForSelector('input[name="email"]', { visible: true });
        await page.type('input[name="email"]', email);
        await page.waitForSelector('input[name="password"]', { visible: true });
        await page.type('input[name="password"]', password);
        console.log('🔐 ログイン実行中...');
        await page.click('button.btn1');
        // 結果待機
        await new Promise(resolve => setTimeout(resolve, 3000));
        // 結果確認
        const currentUrl = page.url();
        const isSuccess = !currentUrl.includes('/login');
        console.log(`✅ ログイン${isSuccess ? '成功' : '失敗'}: ${currentUrl}`);
        // WindSurfと同じシンプルな返却値
        return {
            success: isSuccess,
            url: currentUrl,
            message: isSuccess ? 'ログイン成功' : 'ログイン失敗'
        };
    }
    catch (error) {
        console.error('❌ エラー:', error instanceof Error ? error.message : 'Unknown error');
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error'
        };
    }
    finally {
        if (browser) {
            await browser.close();
        }
    }
}
/**
 * 既存システムとの互換性のためのラッパー
 */
async function authenticateFeelcycleAccountWorking(userId, email, password) {
    console.log(`Working FEELCYCLE認証開始: ${userId}`);
    try {
        const verificationResult = await verifyFeelcycleLogin(email, password);
        if (!verificationResult.success) {
            throw new Error(verificationResult.error || verificationResult.message);
        }
        return {
            success: true,
            data: {
                homeStudio: '取得成功', // 必要に応じて詳細取得を追加
                membershipType: '認証完了',
                currentReservations: [],
                connectedAt: new Date().toISOString()
            }
        };
    }
    catch (error) {
        console.error(`Working FEELCYCLE認証エラー [${userId}]:`, error);
        throw error;
    }
}
