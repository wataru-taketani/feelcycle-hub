import { ProgramData } from '../types/programs';
export declare class ProgramsService {
    /**
     * Store single program data
     */
    storeProgramData(programData: ProgramData): Promise<void>;
    /**
     * Store multiple programs using DynamoDB BatchWrite
     */
    storeProgramsData(programs: ProgramData[]): Promise<void>;
    /**
     * Get all programs
     */
    getAllPrograms(): Promise<ProgramData[]>;
    /**
     * Get program by program code
     */
    getProgramByCode(programCode: string): Promise<ProgramData | null>;
    /**
     * Get programs by genre
     */
    getProgramsByGenre(genre: string): Promise<ProgramData[]>;
}
