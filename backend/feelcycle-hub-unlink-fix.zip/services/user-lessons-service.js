"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserLessonsService = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dateUtils_1 = require("../utils/dateUtils");
const dynamoClient = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION || 'ap-northeast-1' });
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
class UserLessonsService {
    tableName;
    constructor() {
        this.tableName = process.env.USER_LESSONS_TABLE_NAME || '';
        if (!this.tableName) {
            throw new Error('USER_LESSONS_TABLE_NAME environment variable not set');
        }
    }
    /**
     * 気になるリストに追加
     */
    async addToFavorites(userId, lessonInfo) {
        const record = {
            PK: `USER#${userId}`,
            SK: `LESSON#${lessonInfo.studioCode}#${lessonInfo.lessonDate}#${lessonInfo.startTime}#favorite`,
            userId,
            studioCode: lessonInfo.studioCode,
            lessonDate: lessonInfo.lessonDate,
            startTime: lessonInfo.startTime,
            lessonName: lessonInfo.lessonName,
            instructor: lessonInfo.instructor,
            type: 'favorite',
            status: 'active',
            createdAt: (0, dateUtils_1.getJSTISOString)(),
            updatedAt: (0, dateUtils_1.getJSTISOString)(),
            lessonDateTime: `${lessonInfo.lessonDate}T${lessonInfo.startTime}:00+09:00`,
            notes: lessonInfo.notes,
        };
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: record,
        }));
        return record;
    }
    /**
     * キャンセル待ちに追加
     */
    async addToWaitlist(userId, lessonInfo) {
        const record = {
            PK: `USER#${userId}`,
            SK: `LESSON#${lessonInfo.studioCode}#${lessonInfo.lessonDate}#${lessonInfo.startTime}#waitlist`,
            userId,
            studioCode: lessonInfo.studioCode,
            lessonDate: lessonInfo.lessonDate,
            startTime: lessonInfo.startTime,
            lessonName: lessonInfo.lessonName,
            instructor: lessonInfo.instructor,
            type: 'waitlist',
            status: 'active',
            createdAt: (0, dateUtils_1.getJSTISOString)(),
            updatedAt: (0, dateUtils_1.getJSTISOString)(),
            lessonDateTime: `${lessonInfo.lessonDate}T${lessonInfo.startTime}:00+09:00`,
            waitlistId: lessonInfo.waitlistId,
            notificationSent: false,
            ttl: lessonInfo.ttlDays ? (0, dateUtils_1.getTTLFromJST)(lessonInfo.ttlDays) : undefined,
        };
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: record,
        }));
        return record;
    }
    /**
     * ユーザーの特定タイプのレッスン関係を取得
     */
    async getUserLessonsByType(userId, type) {
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk_prefix)',
            ExpressionAttributeValues: {
                ':pk': `USER#${userId}`,
                ':sk_prefix': `LESSON#`,
                ':type': type,
            },
            FilterExpression: '#type = :type',
            ExpressionAttributeNames: {
                '#type': 'type',
            },
        }));
        return result.Items;
    }
    /**
     * アクティブなキャンセル待ちを取得（監視用）
     */
    async getActiveWaitlists() {
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: this.tableName,
            IndexName: 'StatusDateTimeIndex',
            KeyConditionExpression: '#status = :status',
            ExpressionAttributeNames: {
                '#status': 'status',
                '#type': 'type',
            },
            ExpressionAttributeValues: {
                ':status': 'active',
                ':type': 'waitlist',
            },
            FilterExpression: '#type = :type',
        }));
        return result.Items;
    }
    /**
     * レッスン関係を削除
     */
    async removeUserLesson(userId, studioCode, lessonDate, startTime, type) {
        await docClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: this.tableName,
            Key: {
                PK: `USER#${userId}`,
                SK: `LESSON#${studioCode}#${lessonDate}#${startTime}#${type}`,
            },
        }));
    }
    /**
     * ステータス更新
     */
    async updateStatus(userId, studioCode, lessonDate, startTime, type, status) {
        await docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: this.tableName,
            Key: {
                PK: `USER#${userId}`,
                SK: `LESSON#${studioCode}#${lessonDate}#${startTime}#${type}`,
            },
            UpdateExpression: 'SET #status = :status, updatedAt = :updatedAt',
            ExpressionAttributeNames: {
                '#status': 'status',
            },
            ExpressionAttributeValues: {
                ':status': status,
                ':updatedAt': (0, dateUtils_1.getJSTISOString)(),
            },
        }));
    }
    /**
     * 通知送信済みマーク
     */
    async markNotificationSent(userId, studioCode, lessonDate, startTime) {
        await docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: this.tableName,
            Key: {
                PK: `USER#${userId}`,
                SK: `LESSON#${studioCode}#${lessonDate}#${startTime}#waitlist`,
            },
            UpdateExpression: 'SET notificationSent = :sent, updatedAt = :updatedAt',
            ExpressionAttributeValues: {
                ':sent': true,
                ':updatedAt': (0, dateUtils_1.getJSTISOString)(),
            },
        }));
    }
}
exports.UserLessonsService = UserLessonsService;
